//
//  calculadoraViewController.swift
//  appTabBarViewController
//
//  Created by Guest User on 07/06/24.
//

import UIKit

class calculadoraViewController: UIViewController {

    
    
    @IBOutlet weak var Entrada: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var step: UIStepper!
    @IBOutlet weak var segmented: UISegmentedControl!
    @IBOutlet weak var salida: UILabel!
    @IBOutlet weak var suma: UIButton!
    @IBOutlet weak var Igual2: UIButton!
    @IBOutlet weak var Resta2: UIButton!
    @IBOutlet weak var multi: UIButton!
    @IBOutlet weak var div: UIButton!
    
    
    
    var num = 0
    var num1 = 0
    var operador = 0
    
    // x = 320    y = 600
    func Vertical (){
        Entrada.frame = CGRect(x:0 , y: 0, width: 370, height:100 )
        
        slider.frame = CGRect(x:10 , y:180 , width: 150, height: 80)
        
        step.frame = CGRect(x:220 , y:200 , width: 150, height: 80)
        
        segmented.frame = CGRect(x:0 , y: 300, width:370 , height: 50)
        
        salida.frame = CGRect(x: 0, y:400 , width:370 , height: 80)
        
        suma.frame = CGRect(x: 0, y:500 , width:95 , height: 50)
        
        Resta2.frame = CGRect(x: 96, y:500 , width:95 , height: 50)
        multi.frame = CGRect(x: 96*2, y:500 , width:95 , height: 50)
        div.frame = CGRect(x: 96*3, y:500 , width:95 , height: 50)
        
        Igual2.frame = CGRect(x: 0, y:550 , width:370 , height: 50)
        
    }
    
    func Horizontal(){
        Entrada.frame = CGRect(x:0 , y: 0, width: 670, height:30 )
        
        slider.frame = CGRect(x:10 , y:40 , width: 250, height: 20)
        
        step.frame = CGRect(x:300 , y:40 , width: 250, height: 20)
        
        segmented.frame = CGRect(x:0 , y: 130, width:670 , height: 25)
        
        salida.frame = CGRect(x: 0, y:160 , width:670 , height: 30)
        
        suma.frame = CGRect(x: 0, y:200 , width:134 , height: 80)
        
        Resta2.frame = CGRect(x: 134, y:200 , width:134 , height: 80)
        multi.frame = CGRect(x: 134*2, y:200 , width:134 , height: 80)
        div.frame = CGRect(x: 134*3, y:200 , width:134 , height: 80)
        
        Igual2.frame = CGRect(x: 134*4, y:200 , width:134 , height: 80)
        
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        if(traitCollection.verticalSizeClass == .compact){
            Horizontal()
        }
        else{
            Vertical()
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Entrada.text = "\(num)"
        self.Segmento(segmented)
        Vertical()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func sliderMove(_ sender: UISlider) {
        num = Int(sender.value)
        step.value = Double(num)
        Entrada.text = "\(num)"
        self.Segmento(segmented)
        
    }
    
    @IBAction func stepMove(_ sender: UIStepper) {
        num = Int(sender.value)
        slider.value=Float(num)
        Entrada.text = "\(num)"
        self.Segmento(segmented)
    }
    
    @IBAction func Segmento(_ sender: UISegmentedControl) {
        let indice : Int = sender.selectedSegmentIndex
        
        Entrada.text = "\(num)"
        if indice == 0
        {
            //verifica la conversion de
            //numeros binarios negativos
            
            var n = String(num,radix:2)
            salida.text = n
        }
        if indice == 1
        {
            //verifica la conversion de
            //numeros binarios negativos
            
            var n = String(num,radix:8)
            salida.text = n
        }
        if indice == 2
        {
            //verifica la conversion de
            //numeros binarios negativos
            
            var n = String(num,radix:16)
            salida.text = n
        }
    }
    
    
    
    @IBAction func mas(_ sender: Any) {
        operador=1
        num1 = num
        num = 0
        Entrada.text = "\(num)"
        step.value = Double(num)
        slider.value=Float(num)
        self.Segmento(segmented)
        
    }
    
    @IBAction func esIgual(_ sender: Any) {
        if(operador == 1){
            num += num1
            self.Segmento(segmented)
        }
        
        if(operador == 2){
            num1 -= num
            num = num1
            self.Segmento(segmented)
        }
        
        if(operador == 3){
            num *= num1
            
            self.Segmento(segmented)
        }
        
        if(operador == 4){
            num1 /= num
            num = num1
            self.Segmento(segmented)
        }
    }
    
    @IBAction func rest(_ sender: Any) {
        operador=2
        num1 = num
        num = 0
        Entrada.text = "\(num)"
        step.value = Double(num)
        slider.value=Float(num)
        self.Segmento(segmented)
    }
    
    @IBAction func dividir(_ sender: Any) {
        operador=4
        num1 = num
        num = 0
        Entrada.text = "\(num)"
        step.value = Double(num)
        slider.value=Float(num)
        self.Segmento(segmented)
    }
    
    @IBAction func multiplicar(_ sender: Any) {
        operador=3
        num1 = num
        num = 0
        Entrada.text = "\(num)"
        step.value = Double(num)
        slider.value=Float(num)
        self.Segmento(segmented)
    }
    

}
