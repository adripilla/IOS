import UIKit

class fotosPViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var precio: UILabel!
    @IBOutlet weak var btnAtras: UIButton!
    @IBOutlet weak var btnAdel: UIButton!
    @IBOutlet weak var picker2: UIPickerView!
    
    var num = 1
    var modelo = "iphone"
    var pre = 0
    var celularData = ["iphone", "samsung", "huawei", "oppo"]
    var preciosData = ["$20000", "$15000", "$7000", "$5000"]
    
    var numeros = [1, 2, 3]
    
    var imagen = "iphone1"
    
    func Vertical (){
        img.frame = CGRect(x: 50, y: 20, width: 280, height: 300)
        btnAtras.frame = CGRect(x: 0, y: 20, width: 50, height: 300)
        btnAdel.frame = CGRect(x: 300, y: 20, width: 50, height: 300)
        precio.frame = CGRect(x: 100, y: 350, width: 200, height: 70)
        picker.frame = CGRect(x: 50, y: 450, width: 200, height: 200)
        picker2.frame = CGRect(x: 250, y: 450, width: 50, height: 200)
        //textoConjuntoA.frame = CGRect(x: botonAsignarSetA.frame.width, y: 30, width: textoConjuntoA.frame.width, height: textoConjuntoA.frame.height)
    }
    
    func Horizontal(){
        img.frame = CGRect(x: 50, y: 80, width: 550, height: 180)
        btnAtras.frame = CGRect(x: 0, y: 80, width: 50, height: 200)
        btnAdel.frame = CGRect(x: 550, y: 80, width: 50, height: 200)
        precio.frame = CGRect(x: 200, y: 0, width: 550, height: 70)
        picker.frame = CGRect(x: 50, y: 200, width: 200, height: 200)
        picker2.frame = CGRect(x: 200, y: 200, width: 50, height: 200)
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        if(traitCollection.verticalSizeClass == .compact){
            Horizontal()
        }
        else{
            Vertical()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self
        picker.dataSource = self
        picker2.delegate = self
        picker2.dataSource = self
        Vertical()
        updateImage()
    }

    @IBAction func atras(_ sender: UIButton) {
        if num > 1 {
            num -= 1
        } else {
            num = 3
        }
        updateImage()
    }
    
    @IBAction func adelante(_ sender: UIButton) {
        if num < 3 {
            num += 1
        } else {
            num = 1
        }
        updateImage()
    }
    
    // MARK: - UIPickerViewDataSource Methods
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == picker {
            return celularData.count
        } else {
            return numeros.count
        }
    }
    
    // MARK: - UIPickerViewDelegate Methods
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == picker {
            return celularData[row]
        } else {
            return String(numeros[row])
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == picker {
            modelo = celularData[row]
            pre = row
        } else {
            num = numeros[row]
        }
        updateImage()
    }
    
    func updateImage() {
        imagen = "\(modelo)\(num)"
        precio.text = "\(preciosData[pre])"
        img.image = UIImage(named: imagen)
        print("imagen \(imagen)")
    }
}
