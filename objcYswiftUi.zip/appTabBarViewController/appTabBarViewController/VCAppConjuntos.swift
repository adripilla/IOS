//
//  VCAppConjuntos.swift
//  appTabBarViewController
//
//  Created by Guest User on 07/06/24.
//

import UIKit

class VCAppConjuntos: UIViewController {

    var setA = Set<String>()
    var setB = Set<String>()
    
    
    //pendiente añadir las variables para habilitarlo
    
    @IBOutlet weak var textoConjuntoA: UITextField!
    
    @IBOutlet weak var textoConjuntoB: UITextField!
    
    @IBOutlet weak var labelResultado: UITextView!
    
    @IBOutlet weak var botonAsignarSetA: UIButton!
    
    @IBOutlet weak var botonAsignarSetB: UIButton!
    
    @IBOutlet weak var botonUnion: UIButton!
    
    @IBOutlet weak var botonDiferencia: UIButton!
    
    @IBOutlet weak var botonInterseccion: UIButton!
    
    @IBOutlet weak var difSim: UIButton!
    
    @IBOutlet weak var subConj: UIButton!
    
    @IBOutlet weak var superConj: UIButton!
    
    func Vertical (){
        textoConjuntoA.frame = CGRect(x: 46, y: 45, width: 320-46, height: 30)
        
        botonAsignarSetA.frame = CGRect(x: 130, y: 90, width: 60, height: 50)
        
        textoConjuntoB.frame = CGRect(x: 46, y: 160, width: 320-46, height: 30)
        
        botonAsignarSetB.frame = CGRect(x: 130, y: 210, width: 60, height: 50)
        
        botonUnion.frame = CGRect(x: 10, y: 400, width: 80, height: 50)
        
        botonDiferencia.frame = CGRect(x:90, y:400, width: 80, height: 50)
        
        botonInterseccion.frame = CGRect(x: 170, y: 400, width: 80, height: 50)
        
        difSim.frame = CGRect(x: 10, y: 320, width: 80, height: 50)
        
        subConj.frame = CGRect(x:90, y:320, width: 80, height: 50)
        
        superConj.frame = CGRect(x: 170, y: 320, width: 80, height: 50)
        
  
        
        labelResultado.frame = CGRect(x: 46, y: 500, width: 320-46, height: 80)
        
        
    }
    
    func Horizontal(){
        textoConjuntoA.frame = CGRect(x: botonAsignarSetA.frame.width, y: 30, width: textoConjuntoA.frame.width, height: textoConjuntoA.frame.height)
        
        botonAsignarSetA.frame = CGRect(x: 10, y: 30, width: botonAsignarSetA.frame.width, height: botonAsignarSetA.frame.height)
        
        textoConjuntoB.frame = CGRect(x: botonAsignarSetB.frame.width, y: 100, width: textoConjuntoB.frame.width, height: textoConjuntoB.frame.height)
        
        botonAsignarSetB.frame = CGRect(x: 10, y: 100, width: botonAsignarSetB.frame.width, height: botonAsignarSetB.frame.height)
        
        botonUnion.frame = CGRect(x: 10, y: 180, width: botonUnion.frame.width, height: botonUnion.frame.height)
        
        botonDiferencia.frame = CGRect(x: 150, y: 180, width: botonDiferencia.frame.width, height: botonDiferencia.frame.height)
        
        botonInterseccion.frame = CGRect(x: 250, y: 180, width: botonInterseccion.frame.width, height: botonInterseccion.frame.height)
        
        difSim.frame = CGRect(x: 10, y: 240, width: botonUnion.frame.width, height: botonUnion.frame.height)
        
        subConj.frame = CGRect(x: 150, y: 240, width: botonDiferencia.frame.width, height: botonDiferencia.frame.height)
        
        superConj.frame = CGRect(x: 250, y: 240, width: botonInterseccion.frame.width, height: botonInterseccion.frame.height)
        
        labelResultado.frame = CGRect(x:400, y: 30, width: 200, height: 300)
    }
    
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        if(traitCollection.verticalSizeClass == .compact){
            Horizontal()
        }
        else{
            Vertical()
        }
    }
    
    @IBAction func textoSetAChanged(_ sender: UITextField) {
        //VALIDAR EL CONTENIDO Y EL ESTADO DE LOS BOTONES
        if !textoConjuntoA.text!.isEmpty
        {
            botonAsignarSetA.isEnabled = true
            
        }
        
    }
    
    @IBAction func botonAsignarSetA(_ sender: UIButton) {
        
        if !textoConjuntoA.text!.isEmpty
        {
            let conjunto:[String] = textoConjuntoA.text!.components(separatedBy: ",")
            setA = Set<String>()
            //PROBAR SI EL ATRIBUTO APLICA EN SU CONSTRUCCION
            for elemento in conjunto
            {
                setA.insert(elemento)
            }
        }
        
        //checar si se requiere algo mas
        
    }
    
    @IBAction func textoSetBChanged(_ sender: UITextField) {
        if !textoConjuntoB.text!.isEmpty
        {
            botonAsignarSetB.isEnabled = true
        }
    }
    
    
    @IBAction func botonAsignarSetB(_ sender: UIButton) {
        
        if !textoConjuntoB.text!.isEmpty
        {
            let conjunto: [String] = textoConjuntoB.text!.components(separatedBy: ",")
            setB = Set<String>()
            
            for elemento in conjunto
            {
                setB.insert(elemento)
            }
        }
        
        botonUnion.isEnabled = true
        botonDiferencia.isEnabled = true
        botonInterseccion.isEnabled = true
    }
    
    
    @IBAction func btnSup(_ sender: UIButton) {
        let unionAB = setA.isSuperset(of:setB)
        
        labelResultado.text = unionAB ? "es subconjunto" : "no es subconjunto"
    }
    
    @IBAction func btnSub(_ sender: UIButton) {
        let unionAB = setA.isSubset(of:setB)
        
        labelResultado.text = unionAB ? "es subconjunto" : "no es subconjunto"
    }
    @IBAction func btnDifSim(_ sender: UIButton) {
        let unionAB = setA.symmetricDifference(setB).sorted()
        
        labelResultado.text = unionAB.joined(separator: " , ")
    }
    
    @IBAction func botonUnion(_ sender: UIButton) {
        
        let unionAB = setA.union(setB).sorted()
        
        labelResultado.text = unionAB.joined(separator: " , ")
    }
    
    // Método para calcular la diferencia entre los conjuntos setA y setB
        @IBAction func botonDiferencia(_ sender: UIButton) {
            let diferenciaAB = setA.subtracting(setB).sorted()
            labelResultado.text = diferenciaAB.joined(separator: " , ")
        }
        
        // Método para calcular la intersección entre los conjuntos setA y setB
        @IBAction func botonInterseccion(_ sender: UIButton) {
            let interseccionAB = setA.intersection(setB).sorted()
            labelResultado.text = interseccionAB.joined(separator: " , ")
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textoConjuntoB.isEnabled = true
        Vertical()
        // Do any additional setup after loading the view.
    }


}

