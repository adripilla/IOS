//
//  ViewController3D.swift
//  appTabBarViewController
//
//  Created by Guest User on 07/06/24.
//

import UIKit
import SceneKit

class ViewController3D: UIViewController {

    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var seg: UISegmentedControl!
    @IBOutlet weak var lb1: UILabel!
    @IBOutlet weak var lb2: UILabel!
    @IBOutlet weak var lb3: UILabel!
    @IBOutlet weak var lb4: UILabel!
    @IBOutlet weak var lb5: UILabel!
    @IBOutlet weak var lb6: UILabel!
    @IBOutlet weak var sl1: UISlider! //camx
    @IBOutlet weak var sl2: UISlider! //camy
    @IBOutlet weak var sl3: UISlider! //camz
    @IBOutlet weak var sl4: UISlider! //luz x
    @IBOutlet weak var sl5: UISlider! //luz y
    @IBOutlet weak var sl6: UISlider! //luz z
   
    var tipoluz: String?
    
    func Vertical (){
        
        img.frame = CGRect(x: 0, y:0 , width:350 , height: 300)
        
        
        lb1.frame = CGRect(x: 25, y:275 , width:100 , height: 80)
        sl1.frame = CGRect(x: 25, y:290 , width:100 , height: 80)
        
        lb2.frame = CGRect(x: 125, y:275 , width:100 , height: 80)
        sl2.frame = CGRect(x: 125, y:290 , width:100 , height: 80)
        
        lb3.frame = CGRect(x: 225, y:275 , width:100 , height: 80)
        sl3.frame = CGRect(x: 225, y:290 , width:100 , height: 80)
        
        
        lb4.frame = CGRect(x: 25, y:410 , width:100 , height: 80)
        sl4.frame = CGRect(x: 25, y:435 , width:100 , height: 80)
        
        lb5.frame = CGRect(x: 125, y:410 , width:100 , height: 80)
        sl5.frame = CGRect(x: 125, y:435 , width:100 , height: 80)
        
        lb6.frame = CGRect(x: 225, y:410 , width:100 , height: 80)
        sl6.frame = CGRect(x: 225, y:435 , width:100 , height: 80)
        seg.frame = CGRect(x: 25, y:500 , width:270 , height: 80)
        
        
        
        
        
    }
    
    func Horizontal(){
        img.frame = CGRect(x: 300, y:50 , width:270 , height: 240)
        
        
        lb1.frame = CGRect(x: 10, y:0 , width:100 , height: 80)
        sl1.frame = CGRect(x: 100, y:0 , width:100 , height: 80)
        
        lb2.frame = CGRect(x: 10, y:50 , width:100 , height: 80)
        sl2.frame = CGRect(x: 100, y:50 , width:100 , height: 80)
        
        lb3.frame = CGRect(x: 10, y:100 , width:100 , height: 80)
        sl3.frame = CGRect(x: 100, y:100 , width:100 , height: 80)
        
        
        lb4.frame = CGRect(x: 10, y:150 , width:100 , height: 80)
        sl4.frame = CGRect(x: 100, y:150 , width:100 , height: 80)
        
        lb5.frame = CGRect(x: 10, y:200 , width:100 , height: 80)
        sl5.frame = CGRect(x: 100, y:200 , width:100 , height: 80)
        
        lb6.frame = CGRect(x: 10, y:250 , width:100 , height: 80)
        sl6.frame = CGRect(x: 100, y:250 , width:100 , height: 80)
        seg.frame = CGRect(x: 10, y:300 , width:180 , height: 30)
        
        
        
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        if(traitCollection.verticalSizeClass == .compact){
            Horizontal()
        }
        else{
            Vertical()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        Vertical()
        tipoluz = "ambient"
        dibujaObjetos3D()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func slider1(_ sender: UISlider) {
        sl1.value = sender.value
        dibujaObjetos3D()
    }
    
    @IBAction func slider2(_ sender: UISlider) {
        sl2.value = sender.value
        dibujaObjetos3D()
    }
    
    @IBAction func slider3(_ sender: UISlider) {
        sl3.value = sender.value
        dibujaObjetos3D()
    }
    @IBAction func slider4(_ sender: UISlider) {
        sl4.value = sender.value
        dibujaObjetos3D()
    }
    @IBAction func slider5(_ sender: UISlider) {
        sl5.value = sender.value
        dibujaObjetos3D()
    }
    
    @IBAction func slider6(_ sender: UISlider) {
        sl6.value = sender.value
        dibujaObjetos3D()
    }
    
    @IBAction func segmented(_ sender: UISegmentedControl) {
        let indice : Int = seg.selectedSegmentIndex
        switch indice{
        case 0:tipoluz = "ambient"
            
        case 1:tipoluz = "directional"
            
        case 2:tipoluz = "omni"
            
        case 3:tipoluz = "spot"
            
        case 4:tipoluz = "prove"
            
        case 5:tipoluz = "area"
            
        default : tipoluz = "directional"
            
        //agregar los 3 tipos de luz que faltan
            
        }
        dibujaObjetos3D()
    }
    
    func dibujaObjetos3D()
    {
        //CREAMOS VISTA DE LA ESCENA
        
        let sceneView = SCNView(frame:  self.img.frame)
        self.img.addSubview(sceneView)
        
        //CREAMOS LA ESCENA
        let scene = SCNScene()
        sceneView.scene = scene
        
        //CREAMOS LA CAMARA
        let camara = SCNCamera()
        let camaraNodo = SCNNode()
        camaraNodo.camera = camara
        
        //VISTA DE FRENTE
        camaraNodo.position = SCNVector3(self.sl1.value,self.sl2.value,self.sl3.value)
        
        //CREAMOS LA LUZ PARA MANEJAR DIFERENTES TIPOS
        let luz = SCNLight()
        //luz.type = SCNLight.LightType.ambient
        luz.type = SCNLight.LightType(rawValue: tipoluz!)
        
        //HACER INTERACTIVO LOS MOVIMIENTOS DEL ANGULOS
        luz.spotInnerAngle = 30.0
        luz.spotOuterAngle = 70.0
        
        luz.castsShadow = true;
        
        //CREAMOS EL NODO PARA LA LUZ
        let luzNodo = SCNNode()
        luzNodo.light = luz
        luzNodo.position = SCNVector3(sl4.value, sl5.value, sl6.value)
        
        //CUBO
        let geometriaCubo = SCNBox(width: 1.0, height: 1.0, length: 1.0, chamferRadius: 0.1)
        let cuboNodo = SCNNode(geometry: geometriaCubo)
        let constraint = SCNLookAtConstraint(target: cuboNodo)
        constraint.isGimbalLockEnabled = true
        camaraNodo.constraints = [constraint]
        
        //PLANO O PISO
        let planoGeometria = SCNPlane(width: 50/3, height: 50/3)
        let planoNodo = SCNNode(geometry: planoGeometria)
        
        planoNodo.eulerAngles = SCNVector3(GLKMathDegreesToRadians(-90),0.0,0.0)
        
        //VALORES DE LOS ANGULOS INTERACTIVOS
        planoNodo.position = SCNVector3(x: 0.0, y: -0.5, z: 0.0)
        
        //COLOR DE CUBO
        let materialCubo = SCNMaterial()
        materialCubo.metalness.contents = UIColor.systemRed
        
        
        geometriaCubo.materials = [materialCubo]
        cuboNodo.position = SCNVector3(0.5,0,0)
        
        //color y material
        let materialPlano = SCNMaterial()
        materialPlano.diffuse.contents = UIColor.yellow
        planoGeometria.materials = [materialPlano]
        
       
        
        
        
        //agregamos los nodos
        scene.rootNode.addChildNode(luzNodo)
        scene.rootNode.addChildNode(camaraNodo)
        scene.rootNode.addChildNode(cuboNodo)
        scene.rootNode.addChildNode(planoNodo)
    }
}
