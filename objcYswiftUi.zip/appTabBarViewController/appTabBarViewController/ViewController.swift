//
//  ViewController.swift
//  appTabBarViewController
//
//  Created by Guest User on 05/06/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

