import UIKit

class SkyView: UIView {
    private var rageLevel: RageLevel = .caperucita
    private var caperucitaImageView: UIImageView!
    private var waveLayer: CAShapeLayer!
    private var starLayers = [CALayer]()

    func setRageLevel(_ rageLevel: RageLevel) {
        self.rageLevel = rageLevel
        setNeedsDisplay()
    }

    private func degreesToRadians(_ degrees: CGFloat) -> CGFloat {
        return CGFloat.pi * degrees/180.0
    }

    override func draw(_ rect: CGRect) {
        super.draw(rect)
        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }

        let colorSpace = CGColorSpaceCreateDeviceRGB()

        drawSpace(in: rect, context: context, colorSpace: colorSpace)
        drawStars(in: rect, context: context)
        drawPlanet(in: rect, context: context)
        if rageLevel == .caperucita {
            addCaperucita(in: rect)
            addWaveLayerIfNeeded(in: rect)
        } else {
            caperucitaImageView?.removeFromSuperview()
            caperucitaImageView = nil
            waveLayer?.removeFromSuperlayer()
            waveLayer = nil
            removeStarAnimations()
        }
        drawMoon(in: rect, context: context)
        drawDistantStars(in: rect, context: context)
    }

    private func drawStars(in rect: CGRect, context: CGContext) {
        for _ in 0..<50 {
            let starLayer = CALayer()
            starLayer.bounds = CGRect(x: 0, y: 0, width: CGFloat.random(in: 1.0...2.0), height: CGFloat.random(in: 1.0...2.0))
            starLayer.position = CGPoint(x: CGFloat.random(in: 0...rect.size.width), y: CGFloat.random(in: 0...rect.size.height))
            starLayer.backgroundColor = UIColor.white.cgColor
            layer.addSublayer(starLayer)
            starLayers.append(starLayer)
        }
    }

    private func drawPlanet(in rect: CGRect, context: CGContext) {
        let planetColor = UIColor(red: 245.0 / 255.0, green: 173.0 / 255.0, blue: 150.0 / 255.0, alpha: 1.0).cgColor

        let planetSize = CGSize(width: 120, height: 120)
        let planetRect = CGRect(x: 500, y: rect.origin.y + 10, width: 50, height: 50)

        context.addEllipse(in: planetRect)
        context.setFillColor(planetColor)
        context.fillPath()

        UIView.animate(withDuration: 20.0, delay: 0, options: [.repeat, .curveLinear], animations: {
            self.setNeedsDisplay()
        }, completion: nil)
    }

    private func addCaperucita(in rect: CGRect) {
        if caperucitaImageView == nil {
            let caperucitaImage = UIImage(named: "nave")!
            caperucitaImageView = UIImageView(image: caperucitaImage)
            caperucitaImageView.frame = CGRect(x: 0, y: 100, width: 25, height: 25)
            addSubview(caperucitaImageView)
        }
    }

    // MARK: - Mouse Tracking

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        moveCaperucita(to: location)
        addStarAnimations()
    }

    private func moveCaperucita(to position: CGPoint) {
        guard let caperucitaImageView = caperucitaImageView else { return }
        let newY = caperucitaImageView.frame.origin.y
        caperucitaImageView.frame.origin = CGPoint(x: position.x, y: newY)
        addStarAnimations()
    }

    private func addStarAnimations() {
        for starLayer in starLayers {
            let animation = CABasicAnimation(keyPath: "position")
            animation.duration = Double.random(in: 5.0...15.0)
            animation.repeatCount = .infinity
            animation.autoreverses = true
            animation.fromValue = starLayer.position
            animation.toValue = CGPoint(x: starLayer.position.x + CGFloat.random(in: -20...20), y: starLayer.position.y + CGFloat.random(in: -20...20))
            starLayer.add(animation, forKey: "position")
        }
    }

    private func removeStarAnimations() {
        for starLayer in starLayers {
            starLayer.removeAllAnimations()
        }
    }

    private func drawSpace(in rect: CGRect, context: CGContext, colorSpace: CGColorSpace) {
        let blackColor = UIColor.black.cgColor
        let darkBlueColor = UIColor(red: 0.0, green: 0.0, blue: 30.0 / 255.0, alpha: 1.0).cgColor
        let otherColor = UIColor(red: 0.5, green: 0.5, blue: 0.0, alpha: 1.0).cgColor // Puedes cambiar esto a cualquier color que desees

        context.saveGState()
        defer { context.restoreGState() }

        let gradientColors: [CGColor]
        if let caperucitaX = caperucitaImageView?.frame.origin.x {
            if caperucitaX > rect.size.width / 2 {
                // Cambia el color si la imagen de la nave espacial está más allá de la mitad de la pantalla
                gradientColors = [blackColor, otherColor]
            } else {
                gradientColors = [blackColor, darkBlueColor]
            }
        } else {
            gradientColors = [blackColor, darkBlueColor]
        }

        let locations: [CGFloat] = [0.0, 1.0]

        let startPoint = CGPoint(x: rect.size.width / 2, y: 0)
        let endPoint = CGPoint(x: rect.size.width / 2, y: rect.size.height)

        if let gradient = CGGradient(colorsSpace: colorSpace, colors: gradientColors as CFArray, locations: locations) {
            context.drawLinearGradient(gradient, start: startPoint, end: endPoint, options: [])
        }
    }


    private func addWaveLayerIfNeeded(in rect: CGRect) {
        if waveLayer == nil {
            waveLayer = CAShapeLayer()
            let path = UIBezierPath()

            // Posición inicial de las ondas
            let startY: CGFloat = 100
            path.move(to: CGPoint(x: rect.minX, y: startY))

            // Longitud de onda igual a la posición X de la imagen de la nave espacial
            guard let caperucitaX = caperucitaImageView?.frame.origin.x else { return }
            let wavelength: CGFloat = caperucitaX

            // Ajustar el rango de la onda
            let startX = min(wavelength, rect.minX)
            let endX = min(wavelength, rect.maxX)

            let amplitude: CGFloat = 20.0
            for x in stride(from: startX, through: endX, by: 10) {
                let y = startY + amplitude * sin((x / wavelength) * (2 * CGFloat.pi))
                path.addLine(to: CGPoint(x: x, y: y))
            }

            waveLayer.path = path.cgPath
            waveLayer.strokeColor = UIColor.white.cgColor
            waveLayer.fillColor = UIColor.clear.cgColor
            waveLayer.lineWidth = 2.0

            layer.insertSublayer(waveLayer, below: caperucitaImageView.layer)
        }
    }

    private func drawMoon(in rect: CGRect, context: CGContext) {
        let moonColor = UIColor(red: 240.0 / 255.0, green: 240.0 / 255.0, blue: 240.0 / 255.0, alpha: 0.8).cgColor

        let moonSize = CGSize(width: 80, height: 80)
        let moonRect = CGRect(x: 200, y: rect.origin.y + 50, width: 80, height: 80)

        context.addEllipse(in: moonRect)
        context.setFillColor(moonColor)
        context.fillPath()
    }

    private func drawDistantStars(in rect: CGRect, context: CGContext) {
        for _ in 0..<20 {
            let starLayer = CALayer()
            starLayer.bounds = CGRect(x: 0, y: 0, width: CGFloat.random(in: 0.5...1.0), height: CGFloat.random(in: 0.5...1.0))
            starLayer.position = CGPoint(x: CGFloat.random(in: 0...rect.size.width), y: CGFloat.random(in: 0...rect.size.height))
            starLayer.backgroundColor = UIColor.white.cgColor
            layer.insertSublayer(starLayer, below: caperucitaImageView?.layer)
            starLayers.append(starLayer)
        }
    }
}
